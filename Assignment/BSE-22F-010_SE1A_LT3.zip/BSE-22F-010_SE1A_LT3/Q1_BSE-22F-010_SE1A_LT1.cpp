#include<stdio.h>
int main()
{
	printf("First Name:Ali \nLast Name:Shahmeer");
	return 0;
}
