#include<stdio.h>
int main()
{
	printf("**** Welcome to Contact Management System ****\n\n");
	printf("\t MAIN MENU\n");
	printf("\t=====================\n");
	printf("\t[1] Add a new Contact\n");
	printf("\t[2] List all Contact\n");
	printf("\t[3] Search for Contact\n");
	printf("\t[4] Edit a Contact\n");
	printf("\t[5] Delete a Contact\n");
	printf("\t[6] Exit\n");
	printf("\t=================\n");
	printf("\tEnter the choice:");
	return 0;
}
