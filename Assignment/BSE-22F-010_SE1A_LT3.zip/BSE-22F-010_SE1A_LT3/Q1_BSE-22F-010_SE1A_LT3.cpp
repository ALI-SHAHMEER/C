#include<stdio.h>
int main()
{
	printf("***********************************\n");
	printf("*PASSWORD PROTECTED PERSONAL DIARY*\n");
	printf("***********************************\n");
	printf("\t MAIN MENU:\n");
	printf("ADD RECORD \t[1]\n");
	printf("VIEW RECORD \t[2]\n");
	printf("EDIT RECORD \t[3]\n");
	printf("DELETE RECORD \t[4]\n");
	printf("EDIT PASSWORD \t[5]\n");
	printf("EXIT \t\t[6]");
	return 0;
}
